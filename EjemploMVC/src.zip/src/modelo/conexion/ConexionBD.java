package modelo.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import controlador.Coordinador;

public class ConexionBD {

	private static final String URL = "jdbc:mysql://localhost:3306/backend?serverTimezone=UTC";
    private static final String USUARIO = "backend";
    private static final String PASSWORD = "Colombia2024++";
    
    public static Connection obtenerConexion() {
        Connection conexion = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
            System.out.println("Conexión exitosa a MySQL");
        } catch (Exception e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
        return conexion;
    }

    public void setCoordinador(Coordinador miCoordinador) {
    }
}